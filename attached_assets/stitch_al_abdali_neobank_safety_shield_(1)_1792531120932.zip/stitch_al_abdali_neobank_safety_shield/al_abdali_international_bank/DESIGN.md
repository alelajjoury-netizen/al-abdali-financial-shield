---
name: Al-Abdali International Bank
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#45464e'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#75777f'
  outline-variant: '#c5c6cf'
  surface-tint: '#4f5e81'
  primary: '#041534'
  on-primary: '#ffffff'
  primary-container: '#1b2a4a'
  on-primary-container: '#8392b7'
  inverse-primary: '#b7c6ee'
  secondary: '#006d37'
  on-secondary: '#ffffff'
  secondary-container: '#6bfe9c'
  on-secondary-container: '#00743a'
  tertiary: '#281000'
  on-tertiary: '#ffffff'
  tertiary-container: '#472000'
  on-tertiary-container: '#dd771a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b7c6ee'
  on-primary-fixed: '#0a1a3a'
  on-primary-fixed-variant: '#384668'
  secondary-fixed: '#6bfe9c'
  secondary-fixed-dim: '#4ae183'
  on-secondary-fixed: '#00210c'
  on-secondary-fixed-variant: '#005228'
  tertiary-fixed: '#ffdcc5'
  tertiary-fixed-dim: '#ffb783'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#713700'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: IBM Plex Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  display-lg-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: IBM Plex Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system embodies the authority of institutional private banking fused with the responsiveness of next-generation mobile fintech. Tailored specifically for modern Arabic-speaking wealth builders, the interface projects calculated assurance, financial wellness, and calm clarity over sensory overload.

### Design Movement: Modern Precision Fintech
The aesthetic blends contemporary high-trust banking minimalism with crisp tonal separation and subtle tactile elements. Key traits include:
- **Right-to-Left (RTL) First Architecture:** Native Arabic layout hierarchy where reading flow, iconography orientation, progress sweeps, and navigation anchors prioritize Arabic cognitive patterns.
- **Controlled Density:** Financial data requires immediate scanability without cognitive fatigue. Metrics, account numbers, and currency denominators are given breathing room via strict baseline vertical rhythms.
- **Tactile Security Accents:** Cards, biometrics, and transaction shields feature soft interior rims, high-fidelity micro-gradients, and quiet elevation that signal stability and digital precision.

## Colors

The palette establishes institutional credibility through deep navy, accented by purposeful semantic signals that manage behavioral friction and celebrate financial growth.

### Palette Architecture
- **Primary Navy Blue (`#1B2A4A`):** The institutional anchor. Applied to top app headers, primary action buttons, sheet headers, active bottom navigation states, and premium neo-banking debit card bases.
- **Secondary Emerald (`#2ECC71`):** Represents prosperity and assurance. Used for positive financial metrics (+JOD / +SAR / +USD), savings targets, growth trackers, verified transaction checkmarks, and active account shield statuses.
- **Tertiary Warm Amber (`#E67E22`):** Used for friction indicators, cooling-off timers, high-risk merchant alerts, and behavioral nudges designed to reduce impulse spending.
- **Neutral Dark Charcoal (`#0F172A`):** Applied to primary monetary figures, display headers, and critical legal text to ensure maximum contrast and crispness on mobile OLED panels.
- **Neutral Muted Gray (`#64748B`):** Assigned to secondary labels, IBAN sub-details, timestamps, and input placeholders.
- **Background & Card Surfaces:** Canvas foundation defaults to `#F8F9FA` to mitigate eye fatigue, while actionable panels, cards, and modal sheets use pure `#FFFFFF` bounded by hairline `#E2E8F0` borders.

## Typography

The design system uses **IBM Plex Sans** (with Arabic glyph coverage via `IBM Plex Sans Arabic`). The typeface strikes an optimal balance between humanistic Arabic calligraphic cadence and strict fintech legibility.

### Rules & Formatting
- **Bidirectional Numerals:** Eastern Arabic numerals (٠-٩) and Western numerals (0-9) are formatted with tabular figure alignments (`tnum`) across all transaction ledgers and balance headers to ensure stable numeric alignment.
- **Leading & Diacritics:** Line heights provide additional vertical headroom (+4px compared to Latin standards) to accommodate Arabic ascenders, descenders, and accent marks without clipping.
- **Hierarchy Mapping:**
  - `display-lg-mobile` anchors total net worth and primary account balances on mobile screens.
  - `headline-lg` and `headline-md` drive transfer screens, beneficiary names, and security modal prompts.
  - `body-md` sets the standard for transaction ledger items and setting items.
  - `label-md` and `label-sm` govern status pills, cool-down timers, and card expiration badges.

## Layout & Spacing

Layout geometry follows an 8-point base grid system (with a secondary 4-point micro-scale for badges, tags, and icons). 

### Mobile-First RTL Layout Structure
- **Canvas Boundaries:** Default mobile padding is `margin-mobile` (16px / 1rem) horizontally. Bottom sheets and fixed primary CTA buttons honor safe-area insets (`env(safe-area-inset-bottom)` + 16px).
- **RTL Sizing & Offsets:** In all flex and grid implementations, logical properties (`margin-inline-start`, `padding-inline-end`) replace physical left/right rules. Icons, chevron indicators, and progress meters mirror across the vertical axis, except for card branding marks and non-directional metrics.
- **Rhythm & Stacking:** Cards within account lists maintain a vertical gap of `space-sm` (8px). Content groups (such as Quick Actions vs. Recent Transactions) maintain a `space-lg` (24px) structural separation.

## Elevation & Depth

Visual hierarchy uses a hybrid model of crisp low-contrast borders and deep ambient shadows, avoiding heavy drops to preserve a refined neobank finish.

### Surface Tiers
- **Tier 0 (Canvas Base):** `#F8F9FA`. Base layer housing scrollable dashboard content.
- **Tier 1 (Surface Containers):** Pure `#FFFFFF` layered over the base with a hairline `1px solid #E2E8F0` border. Paired with a soft ambient shadow: `0 4px 12px -2px rgba(27, 42, 74, 0.04), 0 2px 6px -1px rgba(27, 42, 74, 0.02)`.
- **Tier 2 (Interactive Floating Elements):** Quick transfer tiles, bottom navigation bar, and sticky headers. Elevation increases: `0 10px 24px -4px rgba(27, 42, 74, 0.08)`.
- **Tier 3 (Modals & Bottom Sheets):** Dimming scrim `rgba(15, 23, 42, 0.48)` layered behind a top-radiused container featuring `0 20px 40px -8px rgba(15, 23, 42, 0.2)`.

### Neo-Banking Debit Card Surfaces
Physical-feel virtual debit cards employ dark, multi-stop navy gradients (`linear-gradient(135deg, #1B2A4A 0%, #111B31 60%, #1E3A5F 100%)`) with a subtle inner border highlight (`inset 0 1px 1px 0 rgba(255, 255, 255, 0.15)`) to emulate premium polycarbonate cards.

## Shapes

The design system employs a `Rounded` (Level 2) shape language, striking a balance between consumer fintech approachability and institutional structure.

### Component Radii Mapping
- **Base Elements (`rounded` = 0.5rem / 8px):** Form input fields, checkbox controls, small transaction icons, and tooltip containers.
- **Card Containers (`rounded-lg` = 1rem / 16px):** Account ledger panels, transfer widgets, security shields, and behavioral spending charts.
- **Hero & Debit Cards (`rounded-xl` = 1.5rem / 24px):** Virtual debit cards and top modal sheets.
- **Pills (`rounded-full` = 9999px):** Status chips, cool-down tags, spending alert banners, and primary CTA buttons.

## Components

### Buttons
- **Primary:** Full width on mobile, 48px height, `rounded-full` (pill), solid `#1B2A4A` background with white text. Active state darkens to `#111B31`. Subtle haptic feedback and an interior press scale of 98%.
- **Secondary (Ghost Outline):** 48px height, `rounded-full`, 1.5px border `#1B2A4A`, text `#1B2A4A`, transparent background.
- **Tertiary / Danger Friction Button:** Used for bypassing cool-down impulse controls. 44px height, `#FFF7ED` background, `#E67E22` text, 1px border `#FDBA74`.

### Chips & Pill Badges
- **Savings & Positive Metrics:** Background `#E8F8F0`, text `#1E824C`, font weight `600`, padding `4px 12px`, `rounded-full`. Icon sits on the right in RTL.
- **Impulse Warning / Cool-Down Timer:** Background `#FEF3C7`, text `#B45309`, border `1px solid #FDE68A`. Houses an active countdown timer displaying remaining time before an impulse-spend freeze lifts.

### Input Fields
- **Container:** 52px height, pure `#FFFFFF` background, 1px solid `#E2E8F0`, `rounded` (8px), padding inline 16px.
- **Focus State:** 1.5px solid `#1B2A4A` with an ambient glow (`box-shadow: 0 0 0 3px rgba(27, 42, 74, 0.1)`).
- **RTL Labeling:** Floating label transitions from right-aligned placeholder to top-right label. Numeric fields (amount, IBAN) enforce right alignment for currency codes and right-to-left cursor progression.

### Lists & Transaction Rows
- **List Container:** Grouped in Tier 1 white cards with `space-sm` separation.
- **Row Architecture:** 64px height. Right-hand slot holds a 40px rounded avatar with brand/merchant iconography. Center slot holds primary merchant name (`body-md`, `#0F172A`) and transaction time (`body-sm`, `#64748B`). Left-hand slot displays formatted amount (+/- value in `label-lg`, with positive amounts in `#2ECC71` and debits in `#0F172A`).
- **Dividers:** Inset 1px line `#F1F5F9` running from merchant text edge to left margin, leaving icons unseparated.

### Checkboxes & Biometric Switches
- **Checkbox:** 20px x 20px, `rounded` (4px). Unchecked: 1.5px solid `#CBD5E1`. Checked: solid `#1B2A4A` with white checkmark glyph.
- **Switch:** 28px height, 48px width, pill shape. Inactive background `#E2E8F0`; Active background `#2ECC71` (indicating active security shield or transaction limit lock). Thumb transitions across the RTL axis smoothly.

### Virtual Debit Card
- **Dimensions:** Standard banking aspect ratio (1.586:1), styled with dark navy gradient, micro-relief chip illustration on the right, bank logo top right, contactless wave glyph top left, masked card number center, and dual balance display bottom left.